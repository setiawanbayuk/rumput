@php
    use Illuminate\Support\Facades\Route;
    use Illuminate\Support\Str;

    /*
     |--------------------------------------------------------------------------
     | Button Admin Final Aman Route
     |--------------------------------------------------------------------------
     | Tujuan:
     | 1. Tidak error lagi saat route lama seperti suket.hapus tidak ada.
     | 2. Tetap support route universal baru: admin.surat.*
     | 3. Tetap support route lama per jenis surat: skbn.*, sktm.*, suket.*, dll.
     | 4. Tombol hanya tampil kalau route-nya memang terdaftar di web.php.
     */

    $id = $id ?? null;
    $route = $route ?? 'admin.surat.edit';
    $status = (int) ($status ?? 0);

    $submitterType = $submitter_type ?? ($status === 0 ? 'warga' : 'admin');
    $isWarga = $submitterType === 'warga';

    $isManual = !empty($manual_signature);
    $hasProof = !empty($bukti_ttd_basah);
    $isManualFinal = $isManual && $hasProof;

    $user = auth()->user();
    $role = (int) ($user->role_id ?? 0);

    $makeRouteName = function (?string $editRoute, string $target) {
        $editRoute = $editRoute ?: 'admin.surat.edit';

        if (Str::endsWith($editRoute, '.edit')) {
            return Str::replaceLast('.edit', '.' . $target, $editRoute);
        }

        return $editRoute . '.' . $target;
    };

    $routeName = function (string $target) use ($route, $makeRouteName) {
        return $makeRouteName($route, $target);
    };

    $routeExists = function (?string $name) {
        return !empty($name) && Route::has($name);
    };

    $routeUrl = function (?string $name, $id) use ($routeExists) {
        if (!$routeExists($name) || empty($id)) {
            return null;
        }

        try {
            return route($name, $id);
        } catch (Throwable $e) {
            return null;
        }
    };

    $editRoute = $route;
    $naikRoute = $routeName('naik');
    $naikLurahRoute = $routeName('naikLurah');
    $tolakRoute = $routeName('tolak');
    $hapusRoute = $routeName('hapus');
    $previewRoute = $routeName('preview');
    $previewBasahRoute = $routeName('previewBasah');
    $cetakRoute = $routeName('cetak');
    $cetakBasahRoute = $routeName('cetakBasah');

    $editUrl = $routeUrl($editRoute, $id);
    $naikUrl = $routeUrl($naikRoute, $id);
    $naikLurahUrl = $routeUrl($naikLurahRoute, $id);
    $tolakUrl = $routeUrl($tolakRoute, $id);
    $hapusUrl = $routeUrl($hapusRoute, $id);
    $previewUrl = $routeUrl($previewRoute, $id);
    $previewBasahUrl = $routeUrl($previewBasahRoute, $id);
    $cetakUrl = $routeUrl($cetakRoute, $id);
    $cetakBasahUrl = $routeUrl($cetakBasahRoute, $id);

    $showNaik = false;
    $naikFinalUrl = null;
    $naikTitle = 'Ajukan ke Atasan';
    $naikConfirm = 'Apakah Anda yakin ingin mengajukan pengajuan ini ke atasan yang lebih tinggi?';
    $naikSuccess = 'Pengajuan berhasil diajukan ke atasan.';

    if (in_array($role, [1, 8, 9], true) && in_array($status, [0, 1], true) && $naikUrl) {
        $showNaik = true;
        $naikFinalUrl = $naikUrl;
    } elseif ($role === 4 && in_array($status, [1, 2], true) && $naikLurahUrl) {
        $showNaik = true;
        $naikFinalUrl = $naikLurahUrl;
        $naikTitle = 'Ajukan ke Lurah';
        $naikConfirm = 'Apakah Anda yakin ingin mengajukan pengajuan ini ke Lurah?';
        $naikSuccess = 'Pengajuan berhasil diajukan ke Lurah.';
    } elseif (in_array($role, [3, 5], true) && in_array($status, [2, 3, 8], true) && $naikUrl) {
        $showNaik = true;
        $naikFinalUrl = $naikUrl;
    }
@endphp

<div class="d-flex gap-1 flex-wrap justify-content-center">
    {{-- FINAL TTD BASAH: hanya preview TTD Basah dan bukti upload --}}
    @if ($isManualFinal)
        @if ($previewBasahUrl)
            <button type="button"
                class="js-surat-action btn btn-secondary btn-sm"
                data-url="{{ $previewBasahUrl }}"
                data-action="preview"
                data-method="GET"
                data-bs-toggle="tooltip"
                title="Preview TTD Basah">
                <i class="ri-file-paper-2-line"></i>
            </button>
        @elseif ($previewUrl)
            <button type="button"
                class="js-surat-action btn btn-secondary btn-sm"
                data-url="{{ $previewUrl }}"
                data-action="preview"
                data-method="GET"
                data-bs-toggle="tooltip"
                title="Preview">
                <i class="ri-file-paper-2-line"></i>
            </button>
        @endif

        <a href="{{ asset($bukti_ttd_basah) }}"
            target="_blank"
            class="btn btn-success btn-sm"
            data-bs-toggle="tooltip"
            title="Preview Bukti Upload">
            <i class="ri-attachment-2"></i>
        </a>

    {{-- STATUS AWAL / DRAFT: tampilkan aksi yang route-nya tersedia --}}
    @elseif (in_array($status, [0, 1], true))
        @if ($showNaik && $naikFinalUrl)
            <button type="button"
                class="js-surat-action btn btn-warning btn-sm"
                data-url="{{ $naikFinalUrl }}"
                data-action="naik"
                data-method="POST"
                data-confirm="{{ $naikConfirm }}"
                data-success="{{ $naikSuccess }}"
                data-bs-toggle="tooltip"
                title="{{ $naikTitle }}">
                <i class="ri-arrow-up-double-fill"></i>
            </button>
        @endif

        @if ($isWarga && $tolakUrl)
            <button type="button"
                class="js-surat-action btn btn-danger btn-sm"
                data-url="{{ $tolakUrl }}"
                data-action="tolak"
                data-method="POST"
                data-confirm="Tolak pengajuan surat ini?"
                data-prompt="Alasan penolakan"
                data-prompt-required="1"
                data-success="Pengajuan berhasil ditolak."
                data-bs-toggle="tooltip"
                title="Tolak">
                <i class="ri-close-circle-line"></i>
            </button>
        @endif

        {{-- Tombol hapus hanya tampil kalau route hapus benar-benar ada. Ini mencegah error Route [suket.hapus] not defined. --}}
        @if ($hapusUrl)
            <button type="button"
                class="js-surat-action btn btn-danger btn-sm"
                data-url="{{ $hapusUrl }}"
                data-action="hapus"
                data-method="DELETE"
                data-confirm="Hapus surat ini?"
                data-success="Surat berhasil dihapus."
                data-bs-toggle="tooltip"
                title="Hapus">
                <i class="ri-delete-bin-6-line"></i>
            </button>
        @endif

        @if ($editUrl)
            <a class="edit btn btn-warning btn-sm"
                href="{{ $editUrl }}"
                data-bs-toggle="tooltip"
                title="Edit">
                <i class="ri-pencil-line"></i>
            </a>
        @endif

        @if ($previewUrl)
            <button type="button"
                class="js-surat-action btn btn-success btn-sm"
                data-url="{{ $previewUrl }}"
                data-action="preview"
                data-method="GET"
                data-bs-toggle="tooltip"
                title="Preview">
                <i class="ri-eye-line"></i>
            </button>
        @endif

        @if ($previewBasahUrl)
            <button type="button"
                class="js-surat-action btn btn-secondary btn-sm"
                data-url="{{ $previewBasahUrl }}"
                data-action="preview_basah"
                data-method="GET"
                data-confirm="Jika memilih TTD Basah, surat akan ditandai sebagai TTD Basah dan Anda wajib upload bukti TTD Basah di menu Edit. Lanjutkan?"
                data-bs-toggle="tooltip"
                title="Preview TTD Basah">
                <i class="ri-file-paper-2-line"></i>
            </button>
        @endif

    {{-- FINAL TTE / DISETUJUI --}}
    @elseif (in_array($status, [4, 9], true))
        @if ($cetakUrl)
            <button type="button"
                class="js-surat-action btn btn-success btn-sm"
                data-url="{{ $cetakUrl }}"
                data-action="cetak"
                data-method="GET"
                data-bs-toggle="tooltip"
                title="Cetak">
                <i class="ri-printer-line"></i>
            </button>
        @elseif ($previewUrl)
            <button type="button"
                class="js-surat-action btn btn-success btn-sm"
                data-url="{{ $previewUrl }}"
                data-action="preview"
                data-method="GET"
                data-bs-toggle="tooltip"
                title="Preview">
                <i class="ri-eye-line"></i>
            </button>
        @endif

    {{-- STATUS LAIN: minimal preview saja --}}
    @else
        @if ($previewUrl)
            <button type="button"
                class="js-surat-action btn btn-success btn-sm"
                data-url="{{ $previewUrl }}"
                data-action="preview"
                data-method="GET"
                data-bs-toggle="tooltip"
                title="Preview">
                <i class="ri-eye-line"></i>
            </button>
        @endif
    @endif
</div>
